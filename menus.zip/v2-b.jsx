// v2 — Direction 3 «الديوان» dark roast (Reem Kufi / copper)
//      Direction 4 «الصحيفة» broadsheet (Noto Kufi / cobalt)

const W3_BG = '#1B1310';
const W3_PAPER = '#F2E9DA';
const W3_AC = '#C9744A';
const W3_MUTED = 'rgba(242,233,218,0.55)';
const W3_DISPLAY = "'Reem Kufi', sans-serif";

function W3Header() {
  const R = MENU_DATA.restaurant;
  return (
    <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid rgba(242,233,218,0.18)', paddingBottom: 16 }}>
      <div>
        <div style={{ fontSize: 38, fontWeight: 600, fontFamily: W3_DISPLAY, lineHeight: 1.35, color: W3_PAPER }}>{R.name}</div>
        <div style={{ fontSize: 12.5, color: W3_MUTED, marginTop: 2 }}>{R.tagline}</div>
      </div>
      <div style={{ textAlign: 'left', paddingTop: 10 }}>
        <div style={{ fontSize: 10.5, letterSpacing: '0.32em', fontWeight: 700, color: W3_AC, direction: 'ltr' }}>{R.name_en}</div>
        <div style={{ fontSize: 8.5, letterSpacing: '0.12em', color: W3_MUTED, marginTop: 5, direction: 'ltr' }}>{R.location_line}</div>
      </div>
    </header>
  );
}

function W3Chip(props) {
  return (
    <div style={{ position: 'absolute', bottom: 10, right: 12, background: 'rgba(27,19,16,0.72)', padding: '3px 11px', borderRadius: 2, display: 'flex', gap: 8, alignItems: 'baseline' }}>
      <span style={{ fontSize: 11, fontWeight: 700, color: W3_PAPER }}>{props.it.name}</span>
      <ItemPrice price={props.it.price} size={11} accent={W3_AC}></ItemPrice>
    </div>
  );
}

function W3CatHead(props) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <h2 style={{ margin: 0, fontSize: 21, fontWeight: 600, fontFamily: W3_DISPLAY, color: W3_AC, lineHeight: 1.5 }}>{props.name}</h2>
      {props.cont ? <ContTag color={'rgba(242,233,218,0.5)'}></ContTag> : null}
      <div style={{ flex: 1, height: 1, background: 'rgba(242,233,218,0.18)' }}></div>
    </div>
  );
}

function W3Cat(props) {
  return (
    <section>
      <W3CatHead name={props.name} cont={props.cont}></W3CatHead>
      <div style={{ marginTop: 2 }}>
        {props.items.map(function (it) {
          return <MenuRow key={it.id} it={it} accent={W3_AC} ink={W3_PAPER} muted={W3_MUTED} metaMuted={'rgba(242,233,218,0.45)'} borderColor="rgba(242,233,218,0.13)" nameSize={14.5} padY={8} clamp={props.clamp || 2}></MenuRow>;
        })}
      </div>
    </section>
  );
}

function W3Page1() {
  const cats = MENU_DATA.categories;
  const band = [cats[0].items[1], cats[1].items[0]]; // جبلي + سبانش لاتيه
  return (
    <div dir="rtl" lang="ar" data-screen-label="D3 الديوان ص١" style={{ width: 794, height: 1123, background: W3_BG, color: W3_PAPER, fontFamily: FONT_BODY2, padding: '42px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <W3Header></W3Header>
      <div style={{ display: 'flex', gap: 3, margin: '24px -56px 0' }}>
        {band.map(function (it) {
          return (
            <div key={it.id} style={{ position: 'relative', flex: 1, height: 234, overflow: 'hidden' }}>
              <SmartImage src={it.image_url} alt={it.name} accent={W3_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
              <W3Chip it={it}></W3Chip>
            </div>
          );
        })}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 44, marginTop: 26 }}>
        <W3Cat name={cats[0].name} items={cats[0].items}></W3Cat>
        <W3Cat name={cats[1].name} items={cats[1].items}></W3Cat>
      </div>
      <MenuFooter border="rgba(242,233,218,0.2)" ink={W3_PAPER} muted={W3_MUTED} pageMuted={W3_MUTED}></MenuFooter>
    </div>
  );
}

function W3Page2() {
  const P2 = MENU_PAGE2;
  return (
    <div dir="rtl" lang="ar" data-screen-label="D3 الديوان ص٢" style={{ width: 794, height: 1123, background: W3_BG, color: W3_PAPER, fontFamily: FONT_BODY2, padding: '42px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <MiniBand accent={W3_AC} font={W3_DISPLAY} weight={600} ink={W3_PAPER} muted={W3_MUTED} rule={'1px solid rgba(242,233,218,0.18)'}></MiniBand>
      <div style={{ position: 'relative', height: 150, overflow: 'hidden', margin: '20px -56px 0' }}>
        <SmartImage src={IMGS2.caramel} alt="آيس لاتيه" accent={W3_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
        <W3Chip it={{ name: 'آيس لاتيه', price: 18 }}></W3Chip>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 44, marginTop: 24 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <W3Cat name={P2.continuation.name} items={P2.continuation.items} cont={true} clamp={1}></W3Cat>
          <W3Cat name={P2.categories[0].name} items={P2.categories[0].items} clamp={1}></W3Cat>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <W3Cat name={P2.categories[1].name} items={P2.categories[1].items} clamp={1}></W3Cat>
          <W3Cat name={P2.categories[2].name} items={P2.categories[2].items} clamp={1}></W3Cat>
        </div>
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()} border="rgba(242,233,218,0.2)" ink={W3_PAPER} muted={W3_MUTED} pageMuted={W3_MUTED}></MenuFooter>
    </div>
  );
}

// ----------------------------------------------------------------------

const W4_AC = '#2A5674';
const W4_DISPLAY = "'Noto Kufi Arabic', sans-serif";

function W4Masthead() {
  const R = MENU_DATA.restaurant;
  return (
    <header>
      <div style={{ borderTop: '3px solid ' + MENU_INK, marginBottom: 2 }}></div>
      <div style={{ borderTop: '1px solid ' + MENU_INK, paddingTop: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div style={{ fontSize: 42, fontWeight: 800, fontFamily: W4_DISPLAY, lineHeight: 1.4 }}>{R.name}</div>
        <div style={{ textAlign: 'left', paddingBottom: 8 }}>
          <div style={{ fontSize: 10, letterSpacing: '0.3em', fontWeight: 700, color: W4_AC, direction: 'ltr' }}>{R.name_en}</div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.1em', color: '#8A8178', direction: 'ltr', marginTop: 3 }}>{R.location_line}</div>
        </div>
      </div>
      <div style={{ borderTop: '1px solid ' + MENU_INK, borderBottom: '1px solid ' + MENU_INK, padding: '5px 0', marginTop: 8, display: 'flex', justifyContent: 'center' }}>
        <span style={{ fontSize: 11.5, color: MENU_MUTED }}>{R.tagline}</span>
      </div>
    </header>
  );
}

function W4CatHead(props) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, borderBottom: '2px solid ' + MENU_INK, paddingBottom: 5 }}>
      <span style={{ fontSize: 26, fontWeight: 800, fontFamily: W4_DISPLAY, color: W4_AC, lineHeight: 1 }}>{arDigits(String(props.n).padStart(2, '0'))}</span>
      <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800, fontFamily: W4_DISPLAY, lineHeight: 1.4 }}>{props.name}</h2>
      {props.cont ? <ContTag color={W4_AC}></ContTag> : null}
    </div>
  );
}

function W4Figure(props) {
  return (
    <figure style={{ margin: '0 0 4px' }}>
      <div style={{ borderTop: '2px solid ' + MENU_INK, paddingTop: 5 }}>
        <div style={{ height: props.h || 206, overflow: 'hidden' }}>
          <SmartImage src={props.it.image_url} alt={props.it.name} accent={W4_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
        </div>
      </div>
      <figcaption style={{ borderBottom: '1px solid ' + MENU_INK, padding: '6px 0', fontSize: 10.5, color: MENU_MUTED, display: 'flex', justifyContent: 'space-between', gap: 8 }}>
        <span>في الصورة: <b style={{ color: MENU_INK }}>{props.it.name}</b></span>
        <ItemPrice price={props.it.price} size={10.5} accent={W4_AC}></ItemPrice>
      </figcaption>
    </figure>
  );
}

function W4Cat(props) {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <W4CatHead n={props.n} name={props.name} cont={props.cont}></W4CatHead>
      <div>
        {props.items.map(function (it) {
          return <MenuRow key={it.id} it={it} accent={W4_AC} leader={true} leaderColor="#B5AB95" nameSize={14.5} padY={8} clamp={props.clamp || 2}></MenuRow>;
        })}
      </div>
    </section>
  );
}

function W4Page1() {
  const cats = MENU_DATA.categories;
  return (
    <div dir="rtl" lang="ar" data-screen-label="D4 الصحيفة ص١" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 54px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <W4Masthead></W4Masthead>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1px 1fr', gap: 24, marginTop: 22, alignItems: 'start' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <W4Figure it={cats[0].items[1]} h={216}></W4Figure>
          <W4Cat n={1} name={cats[0].name} items={cats[0].items}></W4Cat>
        </div>
        <div style={{ background: '#D9CDB9', alignSelf: 'stretch' }}></div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <W4Cat n={2} name={cats[1].name} items={cats[1].items}></W4Cat>
          <W4Figure it={cats[1].items[0]} h={172}></W4Figure>
        </div>
      </div>
      <MenuFooter></MenuFooter>
    </div>
  );
}

function W4Page2() {
  const P2 = MENU_PAGE2;
  return (
    <div dir="rtl" lang="ar" data-screen-label="D4 الصحيفة ص٢" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 54px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div>
        <div style={{ borderTop: '3px solid ' + MENU_INK, marginBottom: 2 }}></div>
        <MiniBand accent={W4_AC} font={W4_DISPLAY} rule={'1px solid ' + MENU_INK}></MiniBand>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1px 1fr', gap: 24, marginTop: 22, alignItems: 'start' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <W4Cat n={2} name={P2.continuation.name} items={P2.continuation.items} cont={true} clamp={1}></W4Cat>
          <W4Cat n={3} name={P2.categories[0].name} items={P2.categories[0].items} clamp={1}></W4Cat>
        </div>
        <div style={{ background: '#D9CDB9', alignSelf: 'stretch' }}></div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <W4Figure it={{ name: 'منقوشة جبنة وزعتر', price: 15, image_url: IMGS2.jabali }} h={150}></W4Figure>
          <W4Cat n={4} name={P2.categories[1].name} items={P2.categories[1].items} clamp={1}></W4Cat>
          <W4Cat n={5} name={P2.categories[2].name} items={P2.categories[2].items} clamp={1}></W4Cat>
        </div>
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()}></MenuFooter>
    </div>
  );
}

Object.assign(window, { W3Page1, W3Page2, W4Page1, W4Page2 });
