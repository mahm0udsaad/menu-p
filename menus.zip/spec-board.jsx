// Spec board — palette, type, grid, data rules (deliverables 2–5)

const specInk = '#221C15';
const specMuted = '#6B6258';

function SpecSwatch(props) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ height: 52, borderRadius: 3, background: props.hex, border: props.border ? '1px solid #E3DACB' : 'none' }}></div>
      <div style={{ fontSize: 11, fontWeight: 700, color: specInk }}>{props.name}</div>
      <div style={{ fontSize: 10, color: specMuted, fontFamily: 'ui-monospace, monospace', marginTop: -4 }}>{props.hex}</div>
    </div>
  );
}

function SpecH(props) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '26px 0 12px' }}>
      <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '0.14em', textTransform: 'uppercase', color: specInk }}>{props.children}</div>
      <div style={{ flex: 1, height: 1, background: '#E3DACB' }}></div>
    </div>
  );
}

function SpecRule(props) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '150px 1fr', gap: 14, padding: '8px 0', borderBottom: '1px solid #F0E9DC', fontSize: 11.5, lineHeight: 1.6 }}>
      <div style={{ fontWeight: 700, color: specInk }}>{props.k}</div>
      <div style={{ color: specMuted }}>{props.children}</div>
    </div>
  );
}

function SpecBoard() {
  return (
    <div dir="ltr" lang="en" data-screen-label="Theme spec" style={{ width: 794, height: 1250, background: '#FFFFFF', padding: '40px 48px', boxSizing: 'border-box', fontFamily: "'Cairo', sans-serif", color: specInk, overflow: 'hidden' }}>
      <div style={{ fontSize: 22, fontWeight: 800 }}>Theme spec — MENA editorial menu, page 1</div>
      <div style={{ fontSize: 11.5, color: specMuted, marginTop: 2 }}>Shared across all four directions; only the accent + pattern + layout zoning differ.</div>

      <SpecH>Palette</SpecH>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        <SpecSwatch name="Paper" hex="#FBF7EF" border={true}></SpecSwatch>
        <SpecSwatch name="Ink" hex="#221C15"></SpecSwatch>
        <SpecSwatch name="Muted ink" hex="#6B6258"></SpecSwatch>
        <SpecSwatch name="Hairline" hex="#E3DACB" border={true}></SpecSwatch>
        <SpecSwatch name="Pomegranate (V1)" hex="#8E2A3C"></SpecSwatch>
        <SpecSwatch name="Olive (V2)" hex="#5A6132"></SpecSwatch>
        <SpecSwatch name="Saffron (V3)" hex="#A8701C"></SpecSwatch>
        <SpecSwatch name="Date brown (V4)" hex="#6B3F23"></SpecSwatch>
      </div>
      <div style={{ fontSize: 10.5, color: specMuted, marginTop: 8 }}>One accent per theme instance — never mixed. All accents pass on paper for text ≥ 11px bold.</div>

      <SpecH>Typography — Cairo (Google Fonts, print-safe)</SpecH>
      <div style={{ display: 'grid', gridTemplateColumns: '150px 1fr', rowGap: 6, fontSize: 11.5, lineHeight: 1.6, color: specMuted }}>
        <div style={{ fontWeight: 700, color: specInk }}>Restaurant name</div><div><span dir="rtl" style={{ fontSize: 24, fontWeight: 800, color: specInk }}>أت بيروت</span> &nbsp; 38–42px / 800</div>
        <div style={{ fontWeight: 700, color: specInk }}>Latin name</div><div><span style={{ letterSpacing: '0.3em', fontWeight: 700, fontSize: 11 }}>AT BEIRUT</span> &nbsp; 10–11px / 700 / tracking 0.3em</div>
        <div style={{ fontWeight: 700, color: specInk }}>Category</div><div><span dir="rtl" style={{ fontSize: 17, fontWeight: 800, color: specInk }}>من الفرن</span> &nbsp; 19–22px / 800</div>
        <div style={{ fontWeight: 700, color: specInk }}>Item name</div><div><span dir="rtl" style={{ fontSize: 14, fontWeight: 700, color: specInk }}>زعتر جبلي</span> &nbsp; 15–16px / 700</div>
        <div style={{ fontWeight: 700, color: specInk }}>Description</div><div><span dir="rtl">خلطة الزعتر اللبناني التقليدي…</span> &nbsp; 12px / 400 / line-height 1.7</div>
        <div style={{ fontWeight: 700, color: specInk }}>Meta + footer</div><div>10–10.5px / calories in accent 700, allergens muted 400</div>
      </div>
      <div style={{ fontSize: 10.5, color: specMuted, marginTop: 8 }}>Fallback stack: <span style={{ fontFamily: 'ui-monospace, monospace' }}>'Cairo', 'IBM Plex Sans Arabic', 'Noto Kufi Arabic', sans-serif</span>. Embed fonts in the PDF; never rely on system Arabic fonts.</div>

      <SpecH>Grid &amp; spacing</SpecH>
      <div style={{ fontSize: 11.5, lineHeight: 1.75, color: specMuted }}>
        A4 portrait at 794 × 1123 px (96 dpi). Margins 52px sides / 40px top / 32px bottom (≈ 14 / 11 / 8.5 mm). 8px baseline unit. RTL single text column (V1, V3, V4) or 2-col grid with 40px gutter (V2). Price column is fixed-width, flush to the left margin, tabular numerals — currency mark ر.س sits left of the digits at 60% size. Footer is pinned: QR placeholder + footer_url (left in reading order), page number + «يتبع» (continuation mark) opposite.
      </div>

      <SpecH>Data rules (parser → layout)</SpecH>
      <div>
        <SpecRule k="item.image_url set">V1/V2: photo leaves the list — pulled into an editorial strip / arch gallery with name + price caption, so list rows stay uniform. V3: 52px round thumb in the row. V4: only the first photo of the first category is featured; the rest are held for later pages.</SpecRule>
        <SpecRule k="image_url: null">Nothing is faked. V1/V2/V4: row renders as pure text at full width. V3: tinted disc with the item's first letter — same footprint as a photo, so the column never staggers.</SpecRule>
        <SpecRule k="Long description">Body text clamps at 2 lines (ellipsis); full text reflows on detail/QR view. Line-height 1.7 with text-wrap: pretty keeps Arabic wraps clean. Names never clamp.</SpecRule>
        <SpecRule k="Calories / allergens">Description is split on newlines: a line containing «سعرات» becomes an accent-colored calorie chip; a line starting «الحساسية:» becomes a muted «يحتوي:» note. Body keeps the rest verbatim — nothing invented.</SpecRule>
        <SpecRule k="Category continues on page 2">Category header repeats on the next page with a «— تتمة» suffix; the page footer always carries «يتبع» when total_known_categories exceeds what is rendered. Never split one item across pages; minimum 2 items with a header, else push the whole category.</SpecRule>
      </div>
    </div>
  );
}

Object.assign(window, { SpecBoard });
