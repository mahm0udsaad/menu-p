// Variation 1 — "السجل" Editorial Ledger (pomegranate)
// Variation 2 — "أروقة" Arch Gallery (olive)

const V1_ACCENT = '#8E2A3C';
const v1Lattice = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12'%3E%3Cpath d='M6 0L12 6L6 12L0 6Z' fill='none' stroke='%238E2A3C' stroke-width='0.7'/%3E%3C/svg%3E\")";

function V1ImageStrip(props) {
  const imgs = catImages(props.cat).slice(0, 3);
  if (!imgs.length) return null;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(' + imgs.length + ', 1fr)', gap: 10, margin: '12px 0 4px' }}>
      {imgs.map(function (it) {
        return (
          <figure key={it.id} style={{ margin: 0 }}>
            <div style={{ height: 112, overflow: 'hidden', borderRadius: 3 }}>
              <SmartImage src={it.image_url} alt={it.name} accent={V1_ACCENT} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
            </div>
            <figcaption style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 8, marginTop: 5 }}>
              <span style={{ fontSize: 11, fontWeight: 700 }}>{it.name}</span>
              <ItemPrice price={it.price} size={11} accent={V1_ACCENT}></ItemPrice>
            </figcaption>
          </figure>
        );
      })}
    </div>
  );
}

function V1Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 52px', gap: 16, padding: '9px 0', borderBottom: '1px solid #EAE1D2', alignItems: 'start' }}>
      <div>
        <div style={{ fontSize: 15.5, fontWeight: 700, lineHeight: 1.45 }}>{it.name}</div>
        {d.body ? (
          <div style={Object.assign({ fontSize: 12, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1, maxWidth: 540 }, lineClamp(2))}>{d.body}</div>
        ) : null}
        <ItemMeta calories={d.calories} allergens={d.allergens} accent={V1_ACCENT}></ItemMeta>
      </div>
      <div style={{ textAlign: 'left', paddingTop: 2 }}>
        <ItemPrice price={it.price} accent={MENU_INK} size={14.5}></ItemPrice>
      </div>
    </div>
  );
}

function V1Category(props) {
  return (
    <section style={{ marginTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{ fontSize: 10.5, fontWeight: 800, letterSpacing: '0.18em', color: V1_ACCENT }}>{String(props.index + 1).padStart(2, '0')}</span>
        <h2 style={{ margin: 0, fontSize: 21, fontWeight: 800, lineHeight: 1.3 }}>{props.cat.name}</h2>
        <div style={{ flex: 1, height: 1, background: '#D9CDB9' }}></div>
      </div>
      <V1ImageStrip cat={props.cat}></V1ImageStrip>
      <div>
        {props.cat.items.map(function (it) { return <V1Item key={it.id} it={it}></V1Item>; })}
      </div>
    </section>
  );
}

function V1Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  return (
    <div dir="rtl" lang="ar" data-screen-label="V1 السجل" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", padding: '40px 52px 32px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ borderTop: '2.5px solid ' + MENU_INK, paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 38, fontWeight: 800, lineHeight: 1.2 }}>{R.name}</div>
          <div style={{ fontSize: 13, color: MENU_MUTED, marginTop: 0 }}>{R.tagline}</div>
        </div>
        <div style={{ textAlign: 'left', paddingTop: 10 }}>
          <div style={{ fontSize: 11, letterSpacing: '0.3em', fontWeight: 700, color: V1_ACCENT, direction: 'ltr' }}>{R.name_en}</div>
          <div style={{ fontSize: 9, letterSpacing: '0.12em', color: '#8A8178', marginTop: 4, direction: 'ltr' }}>{R.location_line}</div>
        </div>
      </header>
      <div style={{ height: 12, marginTop: 12, backgroundImage: v1Lattice, backgroundSize: '12px 12px', opacity: 0.45 }}></div>
      {MENU_DATA.categories.map(function (cat, i) { return <V1Category key={cat.id} cat={cat} index={i}></V1Category>; })}
      <div style={{ flex: 1 }}></div>
      <footer style={{ borderTop: '1px solid #D9CDB9', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {meta.qr_placeholder ? <QRPlaceholder size={34}></QRPlaceholder> : null}
          <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
        </div>
        <div style={{ fontSize: 10, color: MENU_MUTED }}>صفحة {meta.page_number} · يتبع</div>
      </footer>
    </div>
  );
}

// ----------------------------------------------------------------------

const V2_ACCENT = '#5A6132';
const v2Arches = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='12'%3E%3Cpath d='M0 12 V7 A14 7 0 0 1 28 7 V12' fill='none' stroke='%235A6132' stroke-width='0.8'/%3E%3C/svg%3E\")";

function V2Hero() {
  const imgs = MENU_DATA.categories.reduce(function (acc, c) { return acc.concat(catImages(c)); }, []).slice(0, 3);
  if (!imgs.length) return null;
  // middle arch taller
  const heights = [232, 272, 232];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(' + imgs.length + ', 1fr)', gap: 14, alignItems: 'end', marginTop: 22 }}>
      {imgs.map(function (it, i) {
        return (
          <figure key={it.id} style={{ margin: 0 }}>
            <div style={{ height: heights[i] || 232, overflow: 'hidden', borderRadius: '120px 120px 3px 3px' }}>
              <SmartImage src={it.image_url} alt={it.name} accent={V2_ACCENT} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
            </div>
            <figcaption style={{ textAlign: 'center', marginTop: 8, display: 'flex', justifyContent: 'center', gap: 8, alignItems: 'baseline' }}>
              <span style={{ fontSize: 11.5, fontWeight: 700 }}>{it.name}</span>
              <ItemPrice price={it.price} size={11.5} accent={V2_ACCENT}></ItemPrice>
            </figcaption>
          </figure>
        );
      })}
    </div>
  );
}

function V2Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ padding: '9px 0', borderBottom: '1px dotted #C8BFA8' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'baseline' }}>
        <span style={{ fontSize: 14.5, fontWeight: 700 }}>{it.name}</span>
        <ItemPrice price={it.price} accent={V2_ACCENT} size={13.5}></ItemPrice>
      </div>
      {d.body ? (
        <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1 }, lineClamp(2))}>{d.body}</div>
      ) : null}
      <ItemMeta calories={d.calories} allergens={d.allergens} accent={V2_ACCENT}></ItemMeta>
    </div>
  );
}

function V2Category(props) {
  return (
    <section>
      <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800 }}>{props.cat.name}</h2>
      <div style={{ width: 30, height: 2.5, background: V2_ACCENT, marginTop: 6, marginBottom: 6 }}></div>
      <div>
        {props.cat.items.map(function (it) { return <V2Item key={it.id} it={it}></V2Item>; })}
      </div>
    </section>
  );
}

function V2Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  return (
    <div dir="rtl" lang="ar" data-screen-label="V2 أروقة" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", padding: '42px 54px 32px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 10.5, letterSpacing: '0.42em', fontWeight: 700, color: V2_ACCENT, direction: 'ltr' }}>{R.name_en}</div>
        <div style={{ fontSize: 40, fontWeight: 800, lineHeight: 1.25, marginTop: 4 }}>{R.name}</div>
        <div style={{ fontSize: 13, color: MENU_MUTED }}>{R.tagline}</div>
        <div style={{ fontSize: 9, letterSpacing: '0.14em', color: '#8A8178', direction: 'ltr', marginTop: 6 }}>{R.location_line}</div>
      </header>
      <V2Hero></V2Hero>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginTop: 30 }}>
        {MENU_DATA.categories.map(function (cat) { return <V2Category key={cat.id} cat={cat}></V2Category>; })}
      </div>
      <div style={{ flex: 1 }}></div>
      <div style={{ height: 12, backgroundImage: v2Arches, backgroundSize: '28px 12px', backgroundPosition: 'bottom', opacity: 0.5, marginBottom: 10 }}></div>
      <footer style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {meta.qr_placeholder ? <QRPlaceholder size={34}></QRPlaceholder> : null}
          <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
        </div>
        <div style={{ fontSize: 10, color: MENU_MUTED }}>صفحة {meta.page_number} · يتبع</div>
      </footer>
    </div>
  );
}

Object.assign(window, { V1Page, V2Page });
