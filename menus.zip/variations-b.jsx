// Variation 3 — "الهامش" Saffron Spine (side band)
// Variation 4 — "الصفاء" Quiet Ink (centered, no pattern)

const V3_ACCENT = '#A8701C';
const v3Stars = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='30' height='30'%3E%3Cg fill='none' stroke='white' stroke-width='0.8'%3E%3Crect x='9' y='9' width='12' height='12'/%3E%3Crect x='9' y='9' width='12' height='12' transform='rotate(45 15 15)'/%3E%3C/g%3E%3C/svg%3E\")";

// null image_url fallback (and load-failure fallback): tinted disc with the item's first letter
function V3LetterDisc(props) {
  return (
    <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'rgba(168,112,28,0.12)', display: 'grid', placeItems: 'center', color: V3_ACCENT, fontWeight: 800, fontSize: 19, flex: 'none' }}>
      {props.it.name.trim().charAt(0)}
    </div>
  );
}

function V3Thumb(props) {
  const it = props.it;
  if (it.image_url) {
    return <SmartImage src={it.image_url} alt={it.name} fallback={<V3LetterDisc it={it}></V3LetterDisc>} style={{ width: 52, height: 52, objectFit: 'cover', borderRadius: '50%', display: 'block', flex: 'none' }}></SmartImage>;
  }
  return <V3LetterDisc it={it}></V3LetterDisc>;
}

function V3Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '52px 1fr 52px', gap: 14, alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #EAE1D2' }}>
      <V3Thumb it={it}></V3Thumb>
      <div>
        <div style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.45 }}>{it.name}</div>
        {d.body ? (
          <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.65, color: MENU_MUTED }, lineClamp(2))}>{d.body}</div>
        ) : null}
        <ItemMeta calories={d.calories} allergens={d.allergens} accent={V3_ACCENT}></ItemMeta>
      </div>
      <div style={{ textAlign: 'left' }}>
        <ItemPrice price={it.price} size={14.5} accent={MENU_INK}></ItemPrice>
      </div>
    </div>
  );
}

function V3Category(props) {
  return (
    <section style={{ marginTop: 26 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
        <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>{props.cat.name}</h2>
        <span style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: '0.16em', color: V3_ACCENT }}>{props.cat.items.length} أصناف</span>
      </div>
      <div style={{ height: 2, width: 44, background: V3_ACCENT, margin: '6px 0 2px' }}></div>
      <div>
        {props.cat.items.map(function (it) { return <V3Item key={it.id} it={it}></V3Item>; })}
      </div>
    </section>
  );
}

function V3Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  return (
    <div dir="rtl" lang="ar" data-screen-label="V3 الهامش" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", display: 'flex', boxSizing: 'border-box', overflow: 'hidden' }}>
      <aside style={{ width: 78, background: V3_ACCENT, position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'space-between', padding: '26px 0', flex: 'none' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: v3Stars, backgroundSize: '30px 30px', opacity: 0.16 }}></div>
        <div style={{ writingMode: 'vertical-rl', fontSize: 14, fontWeight: 800, color: '#FDF8EE', letterSpacing: '0.05em', position: 'relative' }}>
          {R.name} <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.28em', opacity: 0.85 }}>· {R.name_en}</span>
        </div>
        <div style={{ width: 30, height: 30, borderRadius: '50%', border: '1.5px solid rgba(253,248,238,0.85)', display: 'grid', placeItems: 'center', color: '#FDF8EE', fontSize: 12, fontWeight: 700, position: 'relative' }}>
          {meta.page_number}
        </div>
      </aside>
      <main style={{ flex: 1, padding: '38px 44px 30px', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderBottom: '2px solid ' + MENU_INK, paddingBottom: 14 }}>
          <div>
            <div style={{ fontSize: 32, fontWeight: 800, lineHeight: 1.25 }}>{R.name}</div>
            <div style={{ fontSize: 12.5, color: MENU_MUTED }}>{R.tagline}</div>
          </div>
          <div style={{ fontSize: 9, letterSpacing: '0.12em', color: '#8A8178', direction: 'ltr', paddingBottom: 4 }}>{R.location_line}</div>
        </header>
        {MENU_DATA.categories.map(function (cat) { return <V3Category key={cat.id} cat={cat}></V3Category>; })}
        <div style={{ flex: 1 }}></div>
        <footer style={{ borderTop: '1px solid #D9CDB9', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {meta.qr_placeholder ? <QRPlaceholder size={34}></QRPlaceholder> : null}
            <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
          </div>
          <div style={{ fontSize: 10, color: MENU_MUTED }}>يتبع في الصفحة التالية</div>
        </footer>
      </main>
    </div>
  );
}

// ----------------------------------------------------------------------

const V4_ACCENT = '#6B3F23';

function V4FeaturedImage(props) {
  const imgs = catImages(props.cat);
  if (!imgs.length || !props.featured) return null;
  const it = imgs[0];
  return (
    <figure style={{ margin: '12px auto 4px', width: 300 }}>
      <div style={{ border: '1px solid ' + V4_ACCENT, padding: 5 }}>
        <SmartImage src={it.image_url} alt={it.name} accent={V4_ACCENT} style={{ width: '100%', height: 158, objectFit: 'cover', display: 'block' }}></SmartImage>
      </div>
      <figcaption style={{ textAlign: 'center', marginTop: 7, fontSize: 10.5, color: MENU_MUTED }}>
        {it.name} — <ItemPrice price={it.price} size={10.5} accent={V4_ACCENT}></ItemPrice>
      </figcaption>
    </figure>
  );
}

function V4Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ textAlign: 'center', maxWidth: 430, margin: '0 auto', padding: '8px 0' }}>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 9, alignItems: 'baseline' }}>
        <span style={{ fontSize: 16, fontWeight: 700 }}>{it.name}</span>
        <span style={{ color: V4_ACCENT, opacity: 0.55 }}>·</span>
        <ItemPrice price={it.price} size={13.5} accent={V4_ACCENT}></ItemPrice>
      </div>
      {d.body ? (
        <div style={Object.assign({ fontSize: 12, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1 }, lineClamp(2))}>{d.body}</div>
      ) : null}
      <ItemMeta calories={d.calories} allergens={d.allergens} accent={V4_ACCENT} center={true}></ItemMeta>
    </div>
  );
}

function V4Category(props) {
  return (
    <section style={{ marginTop: 26 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ flex: 1, height: 1, background: '#D9CDB9' }}></div>
        <h2 style={{ margin: 0, fontSize: 21, fontWeight: 800, whiteSpace: 'nowrap' }}>{props.cat.name}</h2>
        <div style={{ flex: 1, height: 1, background: '#D9CDB9' }}></div>
      </div>
      <V4FeaturedImage cat={props.cat} featured={props.featured}></V4FeaturedImage>
      <div style={{ marginTop: 8 }}>
        {props.cat.items.map(function (it) { return <V4Item key={it.id} it={it}></V4Item>; })}
      </div>
    </section>
  );
}

function V4Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  return (
    <div dir="rtl" lang="ar" data-screen-label="V4 الصفاء" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", padding: '40px 70px 30px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ textAlign: 'center' }}>
        <div style={{ width: 36, height: 2.5, background: V4_ACCENT, margin: '0 auto 14px' }}></div>
        <div style={{ fontSize: 10, letterSpacing: '0.46em', fontWeight: 700, color: V4_ACCENT, direction: 'ltr' }}>{R.name_en}</div>
        <div style={{ fontSize: 42, fontWeight: 800, lineHeight: 1.25, marginTop: 2 }}>{R.name}</div>
        <div style={{ fontSize: 13, color: MENU_MUTED }}>{R.tagline}</div>
        <div style={{ fontSize: 8.5, letterSpacing: '0.16em', color: '#8A8178', direction: 'ltr', marginTop: 8 }}>{R.location_line}</div>
      </header>
      {MENU_DATA.categories.map(function (cat, i) { return <V4Category key={cat.id} cat={cat} featured={i === 0}></V4Category>; })}
      <div style={{ flex: 1 }}></div>
      <footer style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid #D9CDB9', paddingTop: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {meta.qr_placeholder ? <QRPlaceholder size={34} ink={V4_ACCENT}></QRPlaceholder> : null}
          <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
        </div>
        <div style={{ fontSize: 10, color: MENU_MUTED }}>صفحة {meta.page_number} · يتبع</div>
      </footer>
    </div>
  );
}

Object.assign(window, { V3Page, V4Page });
