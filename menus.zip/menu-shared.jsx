// Shared helpers for all menu page variations.
// Parses parser-output fields only; invents nothing.

const MENU_PAPER = '#FBF7EF';
const MENU_INK = '#221C15';
const MENU_MUTED = '#6B6258';
const MENU_HAIRLINE = '#E3DACB';

// Splits a raw item.description into body / calories / allergens.
// Lines containing "سعرات" → calories; lines starting "الحساسية" → allergens.
function parseItemDescription(desc) {
  if (!desc) return { body: null, calories: null, allergens: null };
  const lines = desc.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
  const body = [];
  let calories = null;
  let allergens = null;
  lines.forEach(function (l) {
    if (/سعرات/.test(l)) {
      const m = l.match(/\d+/);
      calories = m ? m[0] : l;
    } else if (/^الحساسية/.test(l)) {
      allergens = l.replace(/^الحساسية[:：]?\s*/, '');
    } else {
      body.push(l);
    }
  });
  return { body: body.join(' ') || null, calories: calories, allergens: allergens };
}

function catImages(cat) {
  return cat.items.filter(function (it) { return !!it.image_url; });
}

function lineClamp(n) {
  return { display: '-webkit-box', WebkitLineClamp: n, WebkitBoxOrient: 'vertical', overflow: 'hidden' };
}

// Price: number + small ر.س — in RTL flow the currency sits to the LEFT of digits.
function ItemPrice(props) {
  const size = props.size || 15;
  const accent = props.accent || MENU_INK;
  return (
    <span style={{ fontWeight: 700, color: accent, fontSize: size, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>
      {props.price}
      <span style={{ fontSize: Math.round(size * 0.6), fontWeight: 600, marginRight: 3, opacity: 0.7 }}>ر.س</span>
    </span>
  );
}

// Calories chip + allergens line, derived only from description text.
function ItemMeta(props) {
  if (!props.calories && !props.allergens) return null;
  return (
    <div style={{ display: 'flex', gap: 12, alignItems: 'baseline', flexWrap: 'wrap', marginTop: 4, justifyContent: props.center ? 'center' : 'flex-start' }}>
      {props.calories ? (
        <span style={{ fontSize: 10.5, fontWeight: 700, color: props.accent, letterSpacing: '0.02em' }}>
          {props.calories} سعرة حرارية
        </span>
      ) : null}
      {props.allergens ? (
        <span style={{ fontSize: 10.5, color: props.muted || '#8A8178' }}>يحتوي: {props.allergens}</span>
      ) : null}
    </div>
  );
}

// QR placeholder (page_meta.qr_placeholder === true)
function QRPlaceholder(props) {
  const size = props.size || 38;
  const ink = props.ink || MENU_INK;
  const corner = { position: 'absolute', width: 7, height: 7, border: '1.5px solid ' + ink };
  return (
    <div style={{ width: size, height: size, border: '1px solid ' + ink, borderRadius: 2, position: 'relative', display: 'grid', placeItems: 'center', flex: 'none' }}>
      <div style={Object.assign({}, corner, { top: 3, right: 3 })}></div>
      <div style={Object.assign({}, corner, { top: 3, left: 3 })}></div>
      <div style={Object.assign({}, corner, { bottom: 3, right: 3 })}></div>
      <div style={{ fontSize: 6.5, fontWeight: 700, letterSpacing: '0.12em', color: ink }}>QR</div>
    </div>
  );
}

// Diamond-lattice texture in a given accent, for image placeholders.
function placeholderPattern(accentHex) {
  const hex = accentHex.replace('#', '');
  return "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14'%3E%3Cpath d='M7 0L14 7L7 14L0 7Z' fill='none' stroke='%23" + hex + "' stroke-width='0.6'/%3E%3C/svg%3E\")";
}

// Image that degrades to a quiet textured slot when the URL can't load
// (CDN hotlink block, expired URL, or image_url that 404s at render time).
function SmartImage(props) {
  const [failed, setFailed] = React.useState(false);
  if (failed && props.fallback) return props.fallback;
  if (failed) {
    const accent = props.accent || '#A8701C';
    const base = Object.assign({}, props.style);
    delete base.objectFit;
    return (
      <div style={Object.assign(base, {
        background: '#F2EADB',
        backgroundImage: placeholderPattern(accent),
        backgroundSize: '14px 14px',
        opacity: 0.85
      })}></div>
    );
  }
  return <img src={props.src} alt={props.alt} onError={function () { setFailed(true); }} style={props.style}></img>;
}

Object.assign(window, {
  MENU_PAPER, MENU_INK, MENU_MUTED, MENU_HAIRLINE,
  parseItemDescription, catImages, lineClamp,
  ItemPrice, ItemMeta, QRPlaceholder, SmartImage, placeholderPattern
});
