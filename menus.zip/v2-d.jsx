// v2 — Direction 7 «الفهرس» plate index (teal / Noto Kufi)
//      Direction 8 «الكتيّب» photo-spine spread (date brown / El Messiri)

const W7_AC = '#1E5C53';
const W7_DISPLAY = "'Noto Kufi Arabic', sans-serif";

function W7Badge(props) {
  return (
    <span style={{
      width: props.size || 18, height: props.size || 18, borderRadius: '50%', flex: 'none',
      display: 'inline-grid', placeItems: 'center',
      background: props.solid ? W7_AC : 'transparent',
      border: props.solid ? 'none' : '1px solid ' + W7_AC,
      color: props.solid ? '#F4EFE2' : W7_AC,
      fontSize: (props.size || 18) * 0.5, fontWeight: 700, lineHeight: 1
    }}>{arDigits(props.n)}</span>
  );
}

function W7Plate(props) {
  return (
    <div style={{ position: 'relative', height: props.h || 128, overflow: 'hidden', borderRadius: 3 }}>
      <SmartImage src={props.it.image_url} alt={props.it.name} accent={W7_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }}></SmartImage>
      <div style={{ position: 'absolute', top: 7, right: 7 }}>
        <W7Badge n={props.n} solid={true} size={21}></W7Badge>
      </div>
    </div>
  );
}

function W7Row(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ padding: '8px 0', borderBottom: '1px solid #E2D8C6' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <span style={{ fontSize: 14.5, fontWeight: 700 }}>{it.name}</span>
        {props.n ? <W7Badge n={props.n} size={16}></W7Badge> : null}
        <span style={{ flex: 1 }}></span>
        <ItemPrice price={it.price} size={13.5} accent={W7_AC}></ItemPrice>
      </div>
      {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1 }, lineClamp(props.clamp || 2))}>{d.body}</div> : null}
      <ItemMeta2 calories={d.calories} allergens={d.allergens} accent={W7_AC}></ItemMeta2>
    </div>
  );
}

function W7CatHead(props) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800, fontFamily: W7_DISPLAY, lineHeight: 1.5 }}>{props.name}</h2>
      {props.cont ? <ContTag color={W7_AC}></ContTag> : null}
      <div style={{ flex: 1, height: 2, background: W7_AC, opacity: 0.22 }}></div>
    </div>
  );
}

// builds {itemId: plateNumber} for a list of categories, starting at `start`
function w7Index(catList, start) {
  const map = {};
  let n = start;
  catList.forEach(function (c) {
    c.items.forEach(function (it) { if (it.image_url) { map[it.id] = n; n += 1; } });
  });
  return map;
}

function W7Page1() {
  const R = MENU_DATA.restaurant;
  const cats = MENU_DATA.categories;
  const idx = w7Index(cats, 1);
  const plates = cats.reduce(function (a, c) { return a.concat(catImages(c)); }, []);
  return (
    <div dir="rtl" lang="ar" data-screen-label="D7 الفهرس ص١" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 50px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '2px solid ' + MENU_INK, paddingBottom: 14 }}>
        <div>
          <div style={{ fontSize: 34, fontWeight: 800, fontFamily: W7_DISPLAY, lineHeight: 1.45 }}>{R.name}</div>
          <div style={{ fontSize: 12.5, color: MENU_MUTED }}>{R.tagline}</div>
        </div>
        <div style={{ textAlign: 'left', paddingTop: 8 }}>
          <div style={{ fontSize: 10, letterSpacing: '0.3em', fontWeight: 700, color: W7_AC, direction: 'ltr' }}>{R.name_en}</div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.1em', color: '#8A8178', direction: 'ltr', marginTop: 4 }}>{R.location_line}</div>
        </div>
      </header>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 186px', gap: 32, marginTop: 22, alignItems: 'start' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22, minWidth: 0 }}>
          {cats.map(function (cat) {
            return (
              <section key={cat.id}>
                <W7CatHead name={cat.name}></W7CatHead>
                <div style={{ marginTop: 2 }}>
                  {cat.items.map(function (it) { return <W7Row key={it.id} it={it} n={idx[it.id]}></W7Row>; })}
                </div>
              </section>
            );
          })}
          <div style={{ fontSize: 9.5, color: '#8A8178' }}>الأرقام تشير إلى الأطباق المصوّرة في العمود الجانبي</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
          {plates.map(function (it, i) { return <W7Plate key={it.id} it={it} n={i + 1} h={136}></W7Plate>; })}
        </div>
      </div>
      <MenuFooter></MenuFooter>
    </div>
  );
}

function W7Page2() {
  const P2 = MENU_PAGE2;
  const allCats = [{ id: 'cont', name: P2.continuation.name, items: P2.continuation.items, cont: true }].concat(P2.categories);
  const idx = w7Index(allCats, 6);
  const plates = allCats.reduce(function (a, c) { return a.concat(c.items.filter(function (it) { return it.image_url; })); }, []);
  const right = allCats.slice(0, 2);
  const left = allCats.slice(2);
  function renderCat(cat) {
    return (
      <section key={cat.id}>
        <W7CatHead name={cat.name} cont={cat.cont}></W7CatHead>
        <div style={{ marginTop: 2 }}>
          {cat.items.map(function (it) { return <W7Row key={it.id} it={it} n={idx[it.id]} clamp={1}></W7Row>; })}
        </div>
      </section>
    );
  }
  return (
    <div dir="rtl" lang="ar" data-screen-label="D7 الفهرس ص٢" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 50px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <MiniBand accent={W7_AC} font={W7_DISPLAY} rule={'2px solid ' + MENU_INK}></MiniBand>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(' + plates.length + ', 1fr)', gap: 9, marginTop: 20 }}>
        {plates.map(function (it, i) { return <W7Plate key={it.id} it={it} n={i + 6} h={118}></W7Plate>; })}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginTop: 22 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>{right.map(renderCat)}</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>{left.map(renderCat)}</div>
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()}></MenuFooter>
    </div>
  );
}

// ----------------------------------------------------------------------

const W8_AC = '#6B3F23';
const W8_DISPLAY = "'El Messiri', sans-serif";

function W8SpineImg(props) {
  return (
    <div style={{ flex: 1, position: 'relative', overflow: 'hidden', minHeight: 0 }}>
      <SmartImage src={props.it.image_url} alt={props.it.name} accent={W8_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }}></SmartImage>
      <div style={{ position: 'absolute', bottom: 0, right: 0, left: 0, background: 'linear-gradient(to top, rgba(30,22,15,0.62), rgba(30,22,15,0))', padding: '22px 12px 9px', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 8 }}>
      <span style={{ fontSize: 11, fontWeight: 700, color: '#F6EFE3' }}>{props.it.name}</span>
        <ItemPrice price={props.it.price} size={11} accent={'#F6EFE3'}></ItemPrice>
      </div>
    </div>
  );
}

function W8Spine(props) {
  return (
    <aside style={{ width: 232, flex: 'none', display: 'flex', flexDirection: 'column', gap: 5, background: '#EFE7D7' }}>
      {props.top ? (
        <div style={{ background: W8_AC, color: '#F4EBDD', textAlign: 'center', padding: '10px 8px', fontSize: 9.5, letterSpacing: '0.32em', fontWeight: 700, direction: 'ltr' }}>{MENU_DATA.restaurant.name_en}</div>
      ) : null}
      {props.items.map(function (it) { return <W8SpineImg key={it.id} it={it}></W8SpineImg>; })}
      {props.bottom ? (
        <div style={{ background: W8_AC, color: '#F4EBDD', textAlign: 'center', padding: '12px 14px', fontSize: 11.5, lineHeight: 1.9 }}>{MENU_DATA.restaurant.tagline}</div>
      ) : null}
    </aside>
  );
}

function W8Cat(props) {
  return (
    <section>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <h2 style={{ margin: 0, fontSize: 21, fontWeight: 700, fontFamily: W8_DISPLAY }}>{props.name}</h2>
        {props.cont ? <ContTag color={W8_AC}></ContTag> : null}
        <div style={{ flex: 1, height: 1, background: '#D5C9B3' }}></div>
      </div>
      <div style={{ marginTop: 2 }}>
        {props.items.map(function (it) {
          return <MenuRow key={it.id} it={it} accent={W8_AC} leader={true} nameSize={15} padY={props.padY || 10} clamp={props.clamp || 2}></MenuRow>;
        })}
      </div>
    </section>
  );
}

function W8Page1() {
  const R = MENU_DATA.restaurant;
  const cats = MENU_DATA.categories;
  const spine = [cats[0].items[1], cats[1].items[0], cats[1].items[1]];
  return (
    <div dir="rtl" lang="ar" data-screen-label="D8 الكتيّب ص١" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, boxSizing: 'border-box', display: 'flex', overflow: 'hidden' }}>
      <W8Spine items={spine} top={true}></W8Spine>
      <main style={{ flex: 1, padding: '46px 46px 28px 40px', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <header>
          <div style={{ width: 36, height: 3, background: W8_AC, marginBottom: 14 }}></div>
          <div style={{ fontSize: 40, fontWeight: 700, fontFamily: W8_DISPLAY, lineHeight: 1.3 }}>{R.name}</div>
          <div style={{ fontSize: 12.5, color: MENU_MUTED, marginTop: 2 }}>{R.tagline}</div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.16em', color: '#8A8178', direction: 'ltr', textAlign: 'right', marginTop: 6 }}>{R.location_line}</div>
        </header>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24, marginTop: 24 }}>
          <W8Cat name={cats[0].name} items={cats[0].items}></W8Cat>
          <W8Cat name={cats[1].name} items={cats[1].items}></W8Cat>
        </div>
        <MenuFooter></MenuFooter>
      </main>
    </div>
  );
}

function W8Page2() {
  const P2 = MENU_PAGE2;
  const spine = [
    { id: 's1', name: 'منقوشة جبنة وزعتر', price: 15, image_url: IMGS2.jabali },
    { id: 's2', name: 'آيس لاتيه', price: 18, image_url: IMGS2.caramel }
  ];
  return (
    <div dir="rtl" lang="ar" data-screen-label="D8 الكتيّب ص٢" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, boxSizing: 'border-box', display: 'flex', overflow: 'hidden' }}>
      <main style={{ flex: 1, padding: '46px 40px 28px 46px', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <MiniBand accent={W8_AC} font={W8_DISPLAY} weight={700} rule={'1px solid #D5C9B3'}></MiniBand>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18, marginTop: 22 }}>
          <W8Cat name={P2.continuation.name} items={P2.continuation.items} cont={true} padY={8} clamp={1}></W8Cat>
          <W8Cat name={P2.categories[0].name} items={P2.categories[0].items} padY={8} clamp={1}></W8Cat>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 36 }}>
            <W8Cat name={P2.categories[1].name} items={P2.categories[1].items} padY={8} clamp={1}></W8Cat>
            <W8Cat name={P2.categories[2].name} items={P2.categories[2].items} padY={8} clamp={1}></W8Cat>
          </div>
        </div>
        <MenuFooter meta={P2.page_meta} text={page2FooterText()}></MenuFooter>
      </main>
      <W8Spine items={spine} bottom={true}></W8Spine>
    </div>
  );
}

Object.assign(window, { W7Page1, W7Page2, W8Page1, W8Page2 });
