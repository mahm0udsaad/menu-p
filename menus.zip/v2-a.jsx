// v2 — Direction 1 «الضيافة» Amiri grand arch (pomegranate)
//      Direction 2 «أروقة» El Messiri arch gallery (olive)

const W1_AC = '#8E2A3C';
const W1_DISPLAY = "'Amiri', serif";

function W1Ornament() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center', marginTop: 5 }}>
      <span style={{ width: 38, height: 1, background: '#C9B894' }}></span>
      <span style={{ width: 5, height: 5, background: W1_AC, transform: 'rotate(45deg)', flex: 'none' }}></span>
      <span style={{ width: 38, height: 1, background: '#C9B894' }}></span>
    </div>
  );
}

function W1Masthead(props) {
  const R = MENU_DATA.restaurant;
  return (
    <header style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 10, letterSpacing: '0.44em', fontWeight: 700, color: W1_AC, direction: 'ltr' }}>{R.name_en}</div>
      <div style={{ fontSize: 54, fontWeight: 700, fontFamily: W1_DISPLAY, lineHeight: 1.25, marginTop: 2 }}>{R.name}</div>
      <div style={{ fontSize: 13, color: MENU_MUTED, marginTop: -4 }}>{R.tagline}</div>
      <div style={{ fontSize: 8.5, letterSpacing: '0.18em', color: '#8A8178', direction: 'ltr', marginTop: 6 }}>{R.location_line}</div>
      <W1Ornament></W1Ornament>
    </header>
  );
}

function W1CatHead(props) {
  return (
    <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0 }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <h2 style={{ margin: 0, fontSize: 25, fontWeight: 700, fontFamily: W1_DISPLAY }}>{props.name}</h2>
        {props.cont ? <ContTag color={W1_AC}></ContTag> : null}
      </div>
      <W1Ornament></W1Ornament>
    </div>
  );
}

function W1Cat(props) {
  return (
    <section>
      <W1CatHead name={props.name} cont={props.cont}></W1CatHead>
      <div style={{ marginTop: 4 }}>
        {props.items.map(function (it) {
          return <MenuRow key={it.id} it={it} accent={W1_AC} leader={true} nameSize={14.5} padY={8}></MenuRow>;
        })}
      </div>
    </section>
  );
}

function W1Page1() {
  const cats = MENU_DATA.categories;
  const hero = cats[0].items[1]; // زعتر جبلي — imaged
  return (
    <div dir="rtl" lang="ar" data-screen-label="D1 الضيافة ص١" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '42px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <W1Masthead></W1Masthead>
      <figure style={{ margin: '18px 0 0' }}>
        <div style={{ border: '1px solid ' + W1_AC, borderRadius: '180px 180px 6px 6px', padding: 7 }}>
          <div style={{ height: 252, overflow: 'hidden', borderRadius: '174px 174px 3px 3px' }}>
            <SmartImage src={hero.image_url} alt={hero.name} accent={W1_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
          </div>
        </div>
        <figcaption style={{ display: 'flex', justifyContent: 'center', gap: 10, alignItems: 'baseline', marginTop: 8, fontSize: 12 }}>
          <span style={{ fontWeight: 700 }}>{hero.name}</span>
          <span style={{ width: 4, height: 4, background: W1_AC, transform: 'rotate(45deg)', alignSelf: 'center' }}></span>
          <ItemPrice price={hero.price} size={12} accent={W1_AC}></ItemPrice>
        </figcaption>
      </figure>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 46, marginTop: 18 }}>
        <W1Cat name={cats[0].name} items={cats[0].items}></W1Cat>
        <W1Cat name={cats[1].name} items={cats[1].items}></W1Cat>
      </div>
      <MenuFooter></MenuFooter>
    </div>
  );
}

function W1Page2() {
  const P2 = MENU_PAGE2;
  return (
    <div dir="rtl" lang="ar" data-screen-label="D1 الضيافة ص٢" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '42px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <MiniBand accent={W1_AC} font={W1_DISPLAY} weight={700} rule={'1px solid #C9B894'}></MiniBand>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 46, marginTop: 24 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 26 }}>
          <W1Cat name={P2.continuation.name} items={P2.continuation.items} cont={true}></W1Cat>
          <W1Cat name={P2.categories[0].name} items={P2.categories[0].items}></W1Cat>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 26 }}>
          <figure style={{ margin: 0 }}>
            <div style={{ border: '1px solid ' + W1_AC, borderRadius: '130px 130px 6px 6px', padding: 6 }}>
              <div style={{ height: 150, overflow: 'hidden', borderRadius: '124px 124px 3px 3px' }}>
                <SmartImage src={IMGS2.spanish} alt="لاتيه" accent={W1_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
              </div>
            </div>
          </figure>
          <W1Cat name={P2.categories[1].name} items={P2.categories[1].items}></W1Cat>
          <W1Cat name={P2.categories[2].name} items={P2.categories[2].items}></W1Cat>
        </div>
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()}></MenuFooter>
    </div>
  );
}

// ----------------------------------------------------------------------

const W2_AC = '#5A6132';
const W2_DISPLAY = "'El Messiri', sans-serif";

function W2Arch(props) {
  return (
    <figure style={{ margin: 0, flex: 1, minWidth: 0 }}>
      <div style={{ height: props.h, overflow: 'hidden', borderRadius: '999px 999px 0 0', border: '1px solid #C9C2A6', borderBottom: 'none', padding: 5, boxSizing: 'border-box' }}>
        <SmartImage src={props.it.image_url} alt={props.it.name} accent={W2_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', borderRadius: '999px 999px 0 0' }}></SmartImage>
      </div>
      <div style={{ height: 4, background: W2_AC }}></div>
      <figcaption style={{ textAlign: 'center', marginTop: 7, display: 'flex', justifyContent: 'center', gap: 8, alignItems: 'baseline' }}>
        <span style={{ fontSize: 11.5, fontWeight: 700 }}>{props.it.name}</span>
        <ItemPrice price={props.it.price} size={11.5} accent={W2_AC}></ItemPrice>
      </figcaption>
    </figure>
  );
}

function W2CatHead(props) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, fontFamily: W2_DISPLAY }}>{props.name}</h2>
      {props.cont ? <ContTag color={W2_AC}></ContTag> : null}
      <div style={{ flex: 1, height: 1, background: '#CFC7AB' }}></div>
      <span style={{ width: 5, height: 5, border: '1px solid ' + W2_AC, transform: 'rotate(45deg)', flex: 'none' }}></span>
    </div>
  );
}

function W2Cat(props) {
  return (
    <section>
      <W2CatHead name={props.name} cont={props.cont}></W2CatHead>
      <div style={{ marginTop: 2 }}>
        {props.items.map(function (it) {
          return <MenuRow key={it.id} it={it} accent={W2_AC} borderStyle="dotted" borderColor="#C2BA9E" nameSize={14.5} padY={8} clamp={props.clamp || 2}></MenuRow>;
        })}
      </div>
    </section>
  );
}

function W2Page1() {
  const R = MENU_DATA.restaurant;
  const cats = MENU_DATA.categories;
  const imgs = cats.reduce(function (a, c) { return a.concat(catImages(c)); }, []).slice(0, 3);
  return (
    <div dir="rtl" lang="ar" data-screen-label="D2 أروقة ص١" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 10, letterSpacing: '0.42em', fontWeight: 700, color: W2_AC, direction: 'ltr' }}>{R.name_en}</div>
        <div style={{ fontSize: 46, fontWeight: 700, fontFamily: W2_DISPLAY, lineHeight: 1.3 }}>{R.name}</div>
        <div style={{ fontSize: 13, color: MENU_MUTED }}>{R.tagline}</div>
        <div style={{ fontSize: 8.5, letterSpacing: '0.16em', color: '#8A8178', direction: 'ltr', marginTop: 5 }}>{R.location_line}</div>
      </header>
      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end', marginTop: 20 }}>
        {imgs.map(function (it, i) { return <W2Arch key={it.id} it={it} h={[206, 248, 206][i] || 206}></W2Arch>; })}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 44, marginTop: 24 }}>
        <W2Cat name={cats[0].name} items={cats[0].items}></W2Cat>
        <W2Cat name={cats[1].name} items={cats[1].items}></W2Cat>
      </div>
      <MenuFooter></MenuFooter>
    </div>
  );
}

function W2Page2() {
  const P2 = MENU_PAGE2;
  return (
    <div dir="rtl" lang="ar" data-screen-label="D2 أروقة ص٢" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <MiniBand accent={W2_AC} font={W2_DISPLAY} weight={700} rule={'1px solid #CFC7AB'}></MiniBand>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 184px', gap: 36, marginTop: 24, alignItems: 'start' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24, minWidth: 0 }}>
          <W2Cat name={P2.continuation.name} items={P2.continuation.items} cont={true} clamp={1}></W2Cat>
          <W2Cat name={P2.categories[0].name} items={P2.categories[0].items} clamp={1}></W2Cat>
          <W2Cat name={P2.categories[1].name} items={P2.categories[1].items} clamp={1}></W2Cat>
          <W2Cat name={P2.categories[2].name} items={P2.categories[2].items} clamp={1}></W2Cat>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <W2Arch it={{ id: 'r1', name: 'لاتيه', price: 18, image_url: IMGS2.spanish }} h={208}></W2Arch>
          <W2Arch it={{ id: 'r2', name: 'منقوشة جبنة وزعتر', price: 15, image_url: IMGS2.jabali }} h={208}></W2Arch>
        </div>
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()}></MenuFooter>
    </div>
  );
}

Object.assign(window, { W1Page1, W1Page2, W2Page1, W2Page2 });
