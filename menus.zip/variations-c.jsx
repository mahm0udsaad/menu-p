// Variation 5 — "الغلاف" Cover hero (deep pomegranate, full-bleed photo)
// Variation 6 — "المقهى الليلي" Dark roast (warm espresso dark, edge-bleed feature rows)

const V5_ACCENT = '#6E2233';

function V5Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  const cats = MENU_DATA.categories;
  const hero = catImages(cats[0])[0] || cats.reduce(function (a, c) { return a.concat(catImages(c)); }, [])[0];
  return (
    <div dir="rtl" lang="ar" data-screen-label="V5 الغلاف" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* full-bleed hero from the first imaged item of the first category */}
      <div style={{ position: 'relative', height: 452, flex: 'none' }}>
        {hero ? (
          <SmartImage src={hero.image_url} alt={hero.name} accent={V5_ACCENT} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
        ) : (
          <div style={{ width: '100%', height: '100%', background: V5_ACCENT }}></div>
        )}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(26,16,14,0.45), rgba(26,16,14,0) 45%)' }}></div>
        {hero ? (
          <div style={{ position: 'absolute', bottom: 14, left: 16, direction: 'rtl', background: 'rgba(26,16,14,0.55)', color: '#F6EFE3', padding: '4px 12px', borderRadius: 2, fontSize: 11, display: 'flex', gap: 8, alignItems: 'baseline' }}>
            <span style={{ fontWeight: 700 }}>{hero.name}</span>
            <ItemPrice price={hero.price} size={11} accent={'#F6EFE3'}></ItemPrice>
          </div>
        ) : null}
      </div>
      <div style={{ padding: '0 52px', flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        {/* paper masthead panel overlapping the hero */}
        <header style={{ marginTop: -62, position: 'relative', background: MENU_PAPER, width: 'fit-content', maxWidth: 460, padding: '14px 0 0 26px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ width: 34, height: 3, background: V5_ACCENT, marginBottom: 8 }}></div>
          <div style={{ fontSize: 36, fontWeight: 800, lineHeight: 1.2 }}>{R.name}</div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'baseline', marginTop: 1 }}>
            <span style={{ fontSize: 10, letterSpacing: '0.3em', fontWeight: 700, color: V5_ACCENT, direction: 'ltr' }}>{R.name_en}</span>
            <span style={{ fontSize: 12, color: MENU_MUTED }}>{R.tagline}</span>
          </div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.14em', color: '#8A8178', direction: 'ltr', marginTop: 5 }}>{R.location_line}</div>
        </header>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginTop: 24 }}>
          {cats.map(function (cat) {
            return (
              <section key={cat.id}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
                  <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800 }}>{cat.name}</h2>
                  <div style={{ flex: 1, height: 1, background: '#D9CDB9', alignSelf: 'center' }}></div>
                </div>
                <div style={{ marginTop: 4 }}>
                  {cat.items.map(function (it) {
                    const d = parseItemDescription(it.description);
                    return (
                      <div key={it.id} style={{ padding: '9px 0', borderBottom: '1px solid #EAE1D2' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'baseline' }}>
                          <span style={{ fontSize: 14.5, fontWeight: 700 }}>{it.name}</span>
                          <ItemPrice price={it.price} accent={V5_ACCENT} size={13.5}></ItemPrice>
                        </div>
                        {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1 }, lineClamp(2))}>{d.body}</div> : null}
                        <ItemMeta calories={d.calories} allergens={d.allergens} accent={V5_ACCENT}></ItemMeta>
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
        <div style={{ flex: 1 }}></div>
        <footer style={{ borderTop: '1px solid #D9CDB9', padding: '10px 0 26px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {meta.qr_placeholder ? <QRPlaceholder size={34}></QRPlaceholder> : null}
            <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
          </div>
          <div style={{ fontSize: 10, color: MENU_MUTED }}>صفحة {meta.page_number} · يتبع</div>
        </footer>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------

const V6_BG = '#1C1511';
const V6_PAPER = '#F4EDE0';
const V6_ACCENT = '#C9744A';
const V6_MUTED = 'rgba(244,237,224,0.55)';

function V6FeatureRow(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  const imageSide = props.flip ? 'left' : 'right';
  const img = (
    <div style={{ width: 236, height: 106, flex: 'none', overflow: 'hidden', marginRight: imageSide === 'right' ? -54 : 0, marginLeft: imageSide === 'left' ? -54 : 0 }}>
      <SmartImage src={it.image_url} alt={it.name} accent={V6_ACCENT} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
    </div>
  );
  const text = (
    <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 14, alignItems: 'baseline' }}>
        <span style={{ fontSize: 16.5, fontWeight: 700, color: V6_PAPER }}>{it.name}</span>
        <ItemPrice price={it.price} size={15} accent={V6_ACCENT}></ItemPrice>
      </div>
      {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.65, color: V6_MUTED, marginTop: 1 }, lineClamp(2))}>{d.body}</div> : null}
      <ItemMeta calories={d.calories} allergens={d.allergens} accent={V6_ACCENT} muted={V6_MUTED}></ItemMeta>
    </div>
  );
  return (
    <div style={{ display: 'flex', gap: 20, alignItems: 'stretch', margin: '10px 0' }}>
      {imageSide === 'right' ? img : text}
      {imageSide === 'right' ? text : img}
    </div>
  );
}

function V6TextRow(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ padding: '8px 0', borderBottom: '1px solid rgba(244,237,224,0.14)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 14, alignItems: 'baseline' }}>
        <span style={{ fontSize: 14.5, fontWeight: 700, color: V6_PAPER }}>{it.name}</span>
        <ItemPrice price={it.price} size={13.5} accent={V6_ACCENT}></ItemPrice>
      </div>
      {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.65, color: V6_MUTED, marginTop: 1 }, lineClamp(1))}>{d.body}</div> : null}
      <ItemMeta calories={d.calories} allergens={d.allergens} accent={V6_ACCENT} muted={V6_MUTED}></ItemMeta>
    </div>
  );
}

function V6Category(props) {
  const cat = props.cat;
  const withImg = cat.items.filter(function (it) { return it.image_url; });
  const noImg = cat.items.filter(function (it) { return !it.image_url; });
  return (
    <section style={{ marginTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800, color: V6_PAPER }}>{cat.name}</h2>
        <div style={{ flex: 1, height: 1, background: 'rgba(244,237,224,0.2)' }}></div>
      </div>
      {withImg.map(function (it, i) {
        return <V6FeatureRow key={it.id} it={it} flip={(props.flipOffset + i) % 2 === 1}></V6FeatureRow>;
      })}
      {noImg.length ? (
        <div style={{ marginTop: 2 }}>
          {noImg.map(function (it) { return <V6TextRow key={it.id} it={it}></V6TextRow>; })}
        </div>
      ) : null}
    </section>
  );
}

function V6Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  let flipOffset = 0;
  return (
    <div dir="rtl" lang="ar" data-screen-label="V6 المقهى الليلي" style={{ width: 794, height: 1123, background: V6_BG, color: V6_PAPER, fontFamily: "'Cairo', sans-serif", padding: '38px 54px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid rgba(244,237,224,0.2)', paddingBottom: 14 }}>
        <div>
          <div style={{ fontSize: 34, fontWeight: 800, lineHeight: 1.2, color: V6_PAPER }}>{R.name}</div>
          <div style={{ fontSize: 12.5, color: V6_MUTED }}>{R.tagline}</div>
        </div>
        <div style={{ textAlign: 'left', paddingTop: 8 }}>
          <div style={{ fontSize: 10.5, letterSpacing: '0.3em', fontWeight: 700, color: V6_ACCENT, direction: 'ltr' }}>{R.name_en}</div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.12em', color: V6_MUTED, marginTop: 4, direction: 'ltr' }}>{R.location_line}</div>
        </div>
      </header>
      {MENU_DATA.categories.map(function (cat, ci) {
        const node = <V6Category key={cat.id} cat={cat} flipOffset={flipOffset}></V6Category>;
        flipOffset += catImages(cat).length;
        return node;
      })}
      <div style={{ flex: 1 }}></div>
      <footer style={{ borderTop: '1px solid rgba(244,237,224,0.2)', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {meta.qr_placeholder ? <QRPlaceholder size={34} ink={V6_PAPER}></QRPlaceholder> : null}
          <div style={{ fontSize: 9, color: V6_MUTED, direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
        </div>
        <div style={{ fontSize: 10, color: V6_MUTED }}>صفحة {meta.page_number} · يتبع</div>
      </footer>
    </div>
  );
}

Object.assign(window, { V5Page, V6Page });
