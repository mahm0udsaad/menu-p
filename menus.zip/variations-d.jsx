// Variation 7 — "الفهرس" Plate index (teal mosaic, numbered cross-references)
// Variation 8 — "النصف" Split page (full-height photo spine)

const V7_ACCENT = '#1E5C53';
const AR_NUMERALS = '٠١٢٣٤٥٦٧٨٩';
function arNum(n) { return String(n).replace(/\d/g, function (d) { return AR_NUMERALS[d]; }); }

// page-order list of imaged items → plate numbers
function plateIndex() {
  const list = MENU_DATA.categories.reduce(function (a, c) { return a.concat(catImages(c)); }, []);
  const map = {};
  list.forEach(function (it, i) { map[it.id] = i + 1; });
  return { list: list, map: map };
}

function V7Badge(props) {
  const solid = props.solid;
  return (
    <span style={{
      width: props.size || 20, height: props.size || 20, borderRadius: '50%', flex: 'none',
      display: 'inline-grid', placeItems: 'center',
      background: solid ? V7_ACCENT : 'transparent',
      border: solid ? 'none' : '1px solid ' + V7_ACCENT,
      color: solid ? '#F6F1E6' : V7_ACCENT,
      fontSize: (props.size || 20) * 0.52, fontWeight: 700, lineHeight: 1
    }}>{arNum(props.n)}</span>
  );
}

function V7Mosaic(props) {
  const list = props.plates.list;
  if (!list.length) return null;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr 1fr', gridTemplateRows: '150px 150px', gap: 8, marginTop: 18 }}>
      {list.slice(0, 5).map(function (it, i) {
        return (
          <div key={it.id} style={{ position: 'relative', overflow: 'hidden', borderRadius: 3, gridRow: i === 0 ? 'span 2' : 'auto' }}>
            <SmartImage src={it.image_url} alt={it.name} accent={V7_ACCENT} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }}></SmartImage>
            <div style={{ position: 'absolute', top: 8, right: 8 }}>
              <V7Badge n={i + 1} solid={true} size={22}></V7Badge>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function V7Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  const plate = props.plates.map[it.id];
  return (
    <div style={{ padding: '9px 0', borderBottom: '1px solid #E2D8C6' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
        <span style={{ fontSize: 14.5, fontWeight: 700 }}>{it.name}</span>
        {plate ? <span style={{ alignSelf: 'center', display: 'inline-flex' }}><V7Badge n={plate} size={16}></V7Badge></span> : null}
        <div style={{ flex: 1 }}></div>
        <ItemPrice price={it.price} accent={V7_ACCENT} size={13.5}></ItemPrice>
      </div>
      {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1 }, lineClamp(2))}>{d.body}</div> : null}
      <ItemMeta calories={d.calories} allergens={d.allergens} accent={V7_ACCENT}></ItemMeta>
    </div>
  );
}

function V7Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  const plates = plateIndex();
  return (
    <div dir="rtl" lang="ar" data-screen-label="V7 الفهرس" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", padding: '40px 52px 30px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 36, fontWeight: 800, lineHeight: 1.2 }}>{R.name}</div>
          <div style={{ fontSize: 12.5, color: MENU_MUTED }}>{R.tagline}</div>
        </div>
        <div style={{ textAlign: 'left', paddingTop: 8 }}>
          <div style={{ fontSize: 10.5, letterSpacing: '0.3em', fontWeight: 700, color: V7_ACCENT, direction: 'ltr' }}>{R.name_en}</div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.12em', color: '#8A8178', marginTop: 4, direction: 'ltr' }}>{R.location_line}</div>
        </div>
      </header>
      <V7Mosaic plates={plates}></V7Mosaic>
      <div style={{ fontSize: 9.5, color: '#8A8178', marginTop: 8 }}>الأرقام تشير إلى الأصناف المصوّرة في القائمة أدناه</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginTop: 18 }}>
        {MENU_DATA.categories.map(function (cat) {
          return (
            <section key={cat.id}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800 }}>{cat.name}</h2>
                <div style={{ flex: 1, height: 2, background: V7_ACCENT, opacity: 0.25 }}></div>
              </div>
              <div style={{ marginTop: 2 }}>
                {cat.items.map(function (it) { return <V7Item key={it.id} it={it} plates={plates}></V7Item>; })}
              </div>
            </section>
          );
        })}
      </div>
      <div style={{ flex: 1 }}></div>
      <footer style={{ borderTop: '1px solid #D9CDB9', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {meta.qr_placeholder ? <QRPlaceholder size={34}></QRPlaceholder> : null}
          <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
        </div>
        <div style={{ fontSize: 10, color: MENU_MUTED }}>صفحة {meta.page_number} · يتبع</div>
      </footer>
    </div>
  );
}

// ----------------------------------------------------------------------

const V8_ACCENT = '#5C3A21';

function V8Spine() {
  const imgs = MENU_DATA.categories.reduce(function (a, c) { return a.concat(catImages(c)); }, []).slice(0, 3);
  return (
    <aside style={{ width: 264, flex: 'none', display: 'flex', flexDirection: 'column', gap: 6, background: '#EFE7D7' }}>
      {imgs.map(function (it) {
        return (
          <div key={it.id} style={{ flex: 1, position: 'relative', overflow: 'hidden', minHeight: 0 }}>
            <SmartImage src={it.image_url} alt={it.name} accent={V8_ACCENT} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }}></SmartImage>
            <div style={{ position: 'absolute', bottom: 0, right: 0, left: 0, background: 'linear-gradient(to top, rgba(30,22,15,0.6), rgba(30,22,15,0))', padding: '20px 12px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 8 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#F6EFE3' }}>{it.name}</span>
              <ItemPrice price={it.price} size={11} accent={'#F6EFE3'}></ItemPrice>
            </div>
          </div>
        );
      })}
    </aside>
  );
}

function V8Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 52px', gap: 16, padding: '9px 0', borderBottom: '1px solid #EAE1D2', alignItems: 'start' }}>
      <div>
        <div style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.45 }}>{it.name}</div>
        {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.7, color: MENU_MUTED, marginTop: 1 }, lineClamp(2))}>{d.body}</div> : null}
        <ItemMeta calories={d.calories} allergens={d.allergens} accent={V8_ACCENT}></ItemMeta>
      </div>
      <div style={{ textAlign: 'left', paddingTop: 2 }}>
        <ItemPrice price={it.price} accent={MENU_INK} size={14}></ItemPrice>
      </div>
    </div>
  );
}

function V8Page() {
  const R = MENU_DATA.restaurant;
  const meta = MENU_DATA.page_meta;
  return (
    <div dir="rtl" lang="ar" data-screen-label="V8 النصف" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: "'Cairo', sans-serif", boxSizing: 'border-box', display: 'flex', overflow: 'hidden' }}>
      <V8Spine></V8Spine>
      <main style={{ flex: 1, padding: '44px 46px 30px', display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <header>
          <div style={{ width: 34, height: 3, background: V8_ACCENT, marginBottom: 12 }}></div>
          <div style={{ fontSize: 37, fontWeight: 800, lineHeight: 1.2 }}>{R.name}</div>
          <div style={{ fontSize: 10, letterSpacing: '0.32em', fontWeight: 700, color: V8_ACCENT, direction: 'ltr', textAlign: 'right', marginTop: 2 }}>{R.name_en}</div>
          <div style={{ fontSize: 12.5, color: MENU_MUTED, marginTop: 4 }}>{R.tagline}</div>
          <div style={{ fontSize: 8.5, letterSpacing: '0.14em', color: '#8A8178', direction: 'ltr', textAlign: 'right', marginTop: 5 }}>{R.location_line}</div>
        </header>
        {MENU_DATA.categories.map(function (cat) {
          return (
            <section key={cat.id} style={{ marginTop: 24 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>{cat.name}</h2>
                <div style={{ flex: 1, height: 1, background: '#D9CDB9' }}></div>
              </div>
              <div style={{ marginTop: 2 }}>
                {cat.items.map(function (it) { return <V8Item key={it.id} it={it}></V8Item>; })}
              </div>
            </section>
          );
        })}
        <div style={{ flex: 1 }}></div>
        <footer style={{ borderTop: '1px solid #D9CDB9', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {meta.qr_placeholder ? <QRPlaceholder size={34}></QRPlaceholder> : null}
            <div style={{ fontSize: 9, color: '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
          </div>
          <div style={{ fontSize: 10, color: MENU_MUTED }}>صفحة {meta.page_number} · يتبع</div>
        </footer>
      </main>
    </div>
  );
}

Object.assign(window, { V7Page, V8Page });
