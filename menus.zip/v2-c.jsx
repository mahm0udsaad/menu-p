// v2 — Direction 5 «الفسيفساء» mosaic cover (saffron / Cairo black)
//      Direction 6 «المشربية» framed centerpiece (deep violet / Amiri)

const W5_AC = '#B97A1F';
const W5_DISPLAY = "'Cairo', sans-serif";

function W5CatHead(props) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ width: 16, height: 3, background: W5_AC, flex: 'none' }}></span>
      <h2 style={{ margin: 0, fontSize: 20, fontWeight: 900, fontFamily: W5_DISPLAY }}>{props.name}</h2>
      {props.cont ? <ContTag color={W5_AC}></ContTag> : null}
      <div style={{ flex: 1, height: 1, background: '#DDD2BC' }}></div>
    </div>
  );
}

function W5Cat(props) {
  return (
    <section>
      <W5CatHead name={props.name} cont={props.cont}></W5CatHead>
      <div style={{ marginTop: 2 }}>
        {props.items.map(function (it) {
          return <MenuRow key={it.id} it={it} accent={W5_AC} nameSize={14.5} padY={8} clamp={props.clamp || 2}></MenuRow>;
        })}
      </div>
    </section>
  );
}

function W5MosaicTile(props) {
  return (
    <div style={{ position: 'relative', overflow: 'hidden', gridRow: props.span2 ? 'span 2' : 'auto' }}>
      <SmartImage src={props.it.image_url} alt={props.it.name} accent={W5_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', position: 'absolute', inset: 0 }}></SmartImage>
      <div style={{ position: 'absolute', bottom: 8, right: 10, background: 'rgba(34,28,21,0.66)', color: '#F6EFE3', padding: '2px 9px', borderRadius: 2, fontSize: 10, display: 'flex', gap: 7, alignItems: 'baseline' }}>
        <span style={{ fontWeight: 700 }}>{props.it.name}</span>
        <ItemPrice price={props.it.price} size={10} accent={'#F0C97E'}></ItemPrice>
      </div>
    </div>
  );
}

function W5Page1() {
  const R = MENU_DATA.restaurant;
  const cats = MENU_DATA.categories;
  const imgs = cats.reduce(function (a, c) { return a.concat(catImages(c)); }, []);
  return (
    <div dir="rtl" lang="ar" data-screen-label="D5 الفسيفساء ص١" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '0 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr', gridTemplateRows: '1fr 1fr', gap: 4, height: 392, margin: '0 -56px', flex: 'none' }}>
        <W5MosaicTile it={imgs[0]} span2={true}></W5MosaicTile>
        {imgs.slice(1, 5).map(function (it) { return <W5MosaicTile key={it.id} it={it}></W5MosaicTile>; })}
      </div>
      <header style={{ width: 470, margin: '-64px auto 0', position: 'relative', background: MENU_PAPER, borderTop: '3px solid ' + W5_AC, textAlign: 'center', padding: '14px 28px 4px', boxSizing: 'border-box' }}>
        <div style={{ fontSize: 9.5, letterSpacing: '0.4em', fontWeight: 700, color: W5_AC, direction: 'ltr' }}>{R.name_en}</div>
        <div style={{ fontSize: 38, fontWeight: 900, fontFamily: W5_DISPLAY, lineHeight: 1.45 }}>{R.name}</div>
        <div style={{ fontSize: 12.5, color: MENU_MUTED, marginTop: -4 }}>{R.tagline}</div>
        <div style={{ fontSize: 8.5, letterSpacing: '0.16em', color: '#8A8178', direction: 'ltr', marginTop: 5 }}>{R.location_line}</div>
      </header>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 44, marginTop: 22 }}>
        <W5Cat name={cats[0].name} items={cats[0].items}></W5Cat>
        <W5Cat name={cats[1].name} items={cats[1].items}></W5Cat>
      </div>
      <MenuFooter></MenuFooter>
    </div>
  );
}

function W5Page2() {
  const P2 = MENU_PAGE2;
  const imgs = [
    { id: 'm1', name: 'منقوشة جبنة وزعتر', price: 15, image_url: IMGS2.jabali },
    { id: 'm2', name: 'لاتيه', price: 18, image_url: IMGS2.spanish },
    { id: 'm3', name: 'آيس لاتيه', price: 18, image_url: IMGS2.caramel }
  ];
  return (
    <div dir="rtl" lang="ar" data-screen-label="D5 الفسيفساء ص٢" style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, padding: '40px 56px 28px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <MiniBand accent={W5_AC} font={W5_DISPLAY} weight={900} rule={'3px solid ' + W5_AC}></MiniBand>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 44, marginTop: 24 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <W5Cat name={P2.continuation.name} items={P2.continuation.items} cont={true} clamp={1}></W5Cat>
          <W5Cat name={P2.categories[0].name} items={P2.categories[0].items} clamp={1}></W5Cat>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <W5Cat name={P2.categories[1].name} items={P2.categories[1].items} clamp={1}></W5Cat>
          <W5Cat name={P2.categories[2].name} items={P2.categories[2].items} clamp={1}></W5Cat>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 4, height: 128, margin: '24px -56px 18px' }}>
        {imgs.map(function (it) { return <W5MosaicTile key={it.id} it={it}></W5MosaicTile>; })}
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()}></MenuFooter>
    </div>
  );
}

// ----------------------------------------------------------------------

const W6_AC = '#4A3268';
const W6_DISPLAY = "'Amiri', serif";
const w6Band = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18'%3E%3Cg fill='none' stroke='%234A3268' stroke-width='0.7'%3E%3Crect x='5.5' y='5.5' width='7' height='7'/%3E%3Crect x='5.5' y='5.5' width='7' height='7' transform='rotate(45 9 9)'/%3E%3C/g%3E%3C/svg%3E\")";

function W6Lattice(props) {
  return <div style={{ height: 18, backgroundImage: w6Band, backgroundSize: '18px 18px', backgroundPosition: 'center', opacity: 0.5, margin: (props.m || '14px') + ' auto', width: props.w || 240 }}></div>;
}

function W6Item(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  return (
    <div style={{ textAlign: 'center', padding: '7px 0' }}>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 10, alignItems: 'baseline' }}>
        <span style={{ fontSize: 16, fontWeight: 700, fontFamily: W6_DISPLAY }}>{it.name}</span>
        <span style={{ width: 4, height: 4, background: W6_AC, transform: 'rotate(45deg)', alignSelf: 'center', flex: 'none' }}></span>
        <ItemPrice price={it.price} size={13} accent={W6_AC}></ItemPrice>
      </div>
      {d.body ? <div style={Object.assign({ fontSize: 11.5, lineHeight: 1.65, color: MENU_MUTED, maxWidth: 440, margin: '1px auto 0' }, lineClamp(1))}>{d.body}</div> : null}
      <ItemMeta2 calories={d.calories} allergens={d.allergens} accent={W6_AC} center={true}></ItemMeta2>
    </div>
  );
}

function W6CatHead(props) {
  return (
    <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <h2 style={{ margin: 0, fontSize: 24, fontWeight: 700, fontFamily: W6_DISPLAY, color: W6_AC }}>{props.name}</h2>
        {props.cont ? <ContTag color={W6_AC}></ContTag> : null}
      </div>
    </div>
  );
}

function W6Cat(props) {
  return (
    <section>
      <W6CatHead name={props.name} cont={props.cont}></W6CatHead>
      <div style={{ marginTop: 2 }}>
        {props.items.map(function (it) { return <W6Item key={it.id} it={it}></W6Item>; })}
      </div>
    </section>
  );
}

function W6Frame(props) {
  return (
    <div dir="rtl" lang="ar" data-screen-label={props.label} style={{ width: 794, height: 1123, background: MENU_PAPER, color: MENU_INK, fontFamily: FONT_BODY2, boxSizing: 'border-box', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 16, border: '1.5px solid ' + W6_AC, pointerEvents: 'none' }}></div>
      <div style={{ position: 'absolute', inset: 22, border: '1px solid rgba(74,50,104,0.3)', pointerEvents: 'none' }}></div>
      <div style={{ position: 'absolute', inset: 22, padding: '26px 52px 20px', display: 'flex', flexDirection: 'column', boxSizing: 'border-box' }}>
        {props.children}
      </div>
    </div>
  );
}

function W6Page1() {
  const R = MENU_DATA.restaurant;
  const cats = MENU_DATA.categories;
  const star = cats[0].items[1];
  return (
    <W6Frame label="D6 المشربية ص١">
      <header style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 9.5, letterSpacing: '0.42em', fontWeight: 700, color: W6_AC, direction: 'ltr' }}>{R.name_en}</div>
        <div style={{ fontSize: 48, fontWeight: 700, fontFamily: W6_DISPLAY, lineHeight: 1.3 }}>{R.name}</div>
        <div style={{ fontSize: 12.5, color: MENU_MUTED, marginTop: -4 }}>{R.tagline}</div>
        <div style={{ fontSize: 8.5, letterSpacing: '0.16em', color: '#8A8178', direction: 'ltr', marginTop: 4 }}>{R.location_line}</div>
      </header>
      <W6Lattice m="10px"></W6Lattice>
      <W6Cat name={cats[0].name} items={cats[0].items}></W6Cat>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 18, margin: '12px 0 6px' }}>
        <div style={{ width: 168, height: 168, clipPath: STAR8_CLIP, overflow: 'hidden', flex: 'none' }}>
          <SmartImage src={star.image_url} alt={star.name} accent={W6_AC} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}></SmartImage>
        </div>
        <div style={{ fontSize: 11, color: MENU_MUTED, maxWidth: 150, lineHeight: 1.8 }}>
          <b style={{ color: MENU_INK }}>{star.name}</b> — طبق الدار <br></br>
          <ItemPrice price={star.price} size={12} accent={W6_AC}></ItemPrice>
        </div>
      </div>
      <W6Cat name={cats[1].name} items={cats[1].items}></W6Cat>
      <MenuFooter border="rgba(74,50,104,0.25)"></MenuFooter>
    </W6Frame>
  );
}

function W6Page2() {
  const P2 = MENU_PAGE2;
  const R = MENU_DATA.restaurant;
  return (
    <W6Frame label="D6 المشربية ص٢">
      <header style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 24, fontWeight: 700, fontFamily: W6_DISPLAY }}>{R.name}</div>
        <div style={{ fontSize: 9, letterSpacing: '0.3em', fontWeight: 700, color: W6_AC, direction: 'ltr', marginTop: 1 }}>{R.name_en}</div>
      </header>
      <W6Lattice m="8px"></W6Lattice>
      <W6Cat name={P2.continuation.name} items={P2.continuation.items} cont={true}></W6Cat>
      <div style={{ height: 12 }}></div>
      <W6Cat name={P2.categories[0].name} items={P2.categories[0].items}></W6Cat>
      <W6Lattice m="8px" w={160}></W6Lattice>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40 }}>
        <W6Cat name={P2.categories[1].name} items={P2.categories[1].items}></W6Cat>
        <W6Cat name={P2.categories[2].name} items={P2.categories[2].items}></W6Cat>
      </div>
      <MenuFooter meta={P2.page_meta} text={page2FooterText()} border="rgba(74,50,104,0.25)"></MenuFooter>
    </W6Frame>
  );
}

Object.assign(window, { W5Page1, W5Page2, W6Page1, W6Page2 });
