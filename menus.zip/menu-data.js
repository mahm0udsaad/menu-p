// Exact parser output sample — Menu-P / menus-sa
window.MENU_DATA = {
  "source": { "type": "menus-sa", "url": "https://atbeirut.menus-sa.com/ar", "resolved_via": "menus-sa" },
  "restaurant": {
    "name": "أت بيروت",
    "name_en": "AT BEIRUT",
    "tagline": "مخبوزات لبنانية ومذاق شرقي معاصر",
    "location_line": "Riyadh | Dine-in | Pickup",
    "language": "ar",
    "direction": "rtl",
    "currency": "SAR",
    "logo_url": null
  },
  "theme_context": { "region": "MENA", "page_size": "A4", "orientation": "portrait", "primary_use": "PDF menu", "print_friendly": true },
  "categories": [
    {
      "id": "main_category_24117",
      "name": "من الفرن",
      "description": null,
      "image_url": null,
      "items": [
        {
          "id": "item_001",
          "name": "زعتر",
          "name_en": null,
          "description": "خلطة الزعتر اللبناني التقليدي مع زيت الزيتون.\n622 سعرات حراريه\nالحساسية: بذور السمسم ومنتجاتها، القمح",
          "price": 10, "currency": "SAR",
          "image_url": "https://menus.sfo3.cdn.digitaloceanspaces.com/43bcdc6cf879b41b10ec20f758c98f04/lXlM3HkNf4NunVbsTMB29AGbN7Jl0c7b8fbhLdHtdPCcJSct1jT7kyJxWL95lYn6ubdSLTPyG3hgAZ2DbxIMWNgCBpYf5dr0dZP5G9KXzwvNJfr1kf1OftAo6JAzC6v1QX6qgcXhJ5jfMKFt5WalZN.jpg",
          "confidence": 1, "flags": []
        },
        {
          "id": "item_002",
          "name": "زعتر جبلي",
          "name_en": null,
          "description": "خلطة الزعتر اللبناني التقليدي مع زيت الزيتون ومغطاة بالزعتر الأخضر، الرمان، البندورة الكرزية ودبس الرمان.",
          "price": 14, "currency": "SAR",
          "image_url": "https://menus.sfo3.cdn.digitaloceanspaces.com/50f229191bfc8f5541bf999c6d1faa71/PAfa8gyazDKgJ9IKKjqHZaLGkTVuYrG8hu3eiW2XjR3o2WHs2udddVcOMZiHtmmFYhiYpT6BK2M51h9P1E6CvLsFBDRBn6m3rr7Kvh3gAHvkHe6SJfPJLm2NoCV0AKWumDhXQcqWptsuuM8ryxbc9k.jpg",
          "confidence": 1, "flags": []
        },
        {
          "id": "item_003",
          "name": "جبنة عكاوي",
          "name_en": null,
          "description": "جبنة عكاوي مخبوزة بعجينة طرية.",
          "price": 16, "currency": "SAR",
          "image_url": null,
          "confidence": 1, "flags": []
        },
        {
          "id": "item_004",
          "name": "لبنة بالعسل",
          "name_en": null,
          "description": "لبنة كريمية مع لمسة عسل وزعتر.",
          "price": 18, "currency": "SAR",
          "image_url": null,
          "confidence": 1, "flags": []
        }
      ]
    },
    {
      "id": "main_category_24134",
      "name": "مشروبات باردة",
      "description": null,
      "image_url": null,
      "items": [
        {
          "id": "item_005",
          "name": "سبانش لاتيه بارد",
          "name_en": null, "description": null,
          "price": 22, "currency": "SAR",
          "image_url": "https://menus.sfo3.cdn.digitaloceanspaces.com/0809aa0801ca8d06efab3920b923c258/lxbt1Upqy5CPGJAFQ4ok7f3iGbaHZLXcv0n5ZMbVgPcXUQPRS0MGubCNvrLX2UBzVMi0oF7KRSF8WmmSJbE4DScPp3QCerbrC4nSZE1CngJrejsiObRnHOxmwVKjwrfidk6MJJB2TxsF14JeiiJ6xl.jpg",
          "confidence": 1, "flags": []
        },
        {
          "id": "item_006",
          "name": "وايت موكا بارد",
          "name_en": null, "description": null,
          "price": 23, "currency": "SAR",
          "image_url": "https://menus.sfo3.cdn.digitaloceanspaces.com/8032668c4fe7aafe61de5629aa2747bc/mmecuXJwzIDGheQEhODivZdmVTHains94WWbGF5aVMxBeCrqcmqDRW9h7IzGb7ugcKP223SGLktftNYYkgnIpvMsJm5zn0dIWg2uNQH082l0IMQYTFNDNS19Ew0LHb8RQOSDTrfUtZZoS8cJNUke1d.jpg",
          "confidence": 1, "flags": []
        },
        {
          "id": "item_007",
          "name": "كراميل لاتيه بارد",
          "name_en": null, "description": null,
          "price": 24, "currency": "SAR",
          "image_url": "https://menus.sfo3.cdn.digitaloceanspaces.com/1e93449fa2f20bd836f6c3cbbbe9a990/jZuBJgtrwMkqPqQ0sBrmhcY7uGTl5Orq67M0qrGHTHpVVPoYDnFg4zqOMHHBYZt1jJgXb0g5nhzhvhL1Hzr8nRO6VuVliPJB2c6I9gvMdpXw1QaTv26Wmq19DEixPH21WKmn6HXLpxek0mcTobLE62.jpg",
          "confidence": 1, "flags": []
        },
        {
          "id": "item_008",
          "name": "آيس أميركانو",
          "name_en": null, "description": null,
          "price": 16, "currency": "SAR",
          "image_url": null,
          "confidence": 1, "flags": []
        }
      ]
    }
  ],
  "page_meta": {
    "page_number": 1,
    "total_known_categories": 19,
    "total_known_items": 160,
    "footer_url": "menu-p.com",
    "qr_placeholder": true
  }
};

// ---------------------------------------------------------------------------
// SYNTHETIC page-2 sample — for pagination testing ONLY.
// Same schema as parser output; image_url values reuse the real CDN photos
// from page 1 (the parser would supply real ones per item).
(function () {
  var c = window.MENU_DATA.categories;
  var img = {
    zaatar: c[0].items[0].image_url,
    jabali: c[0].items[1].image_url,
    spanish: c[1].items[0].image_url,
    mocha: c[1].items[1].image_url,
    caramel: c[1].items[2].image_url
  };
  window.MENU_PAGE2 = {
    continuation: {
      of: "main_category_24134",
      name: "مشروبات باردة",
      items: [
        { id: "item_009", name: "آيس لاتيه", name_en: null, description: null, price: 18, currency: "SAR", image_url: img.caramel, confidence: 1, flags: [] },
        { id: "item_010", name: "ليمون بالنعناع الطازج", name_en: null, description: "عصير ليمون طبيعي مع أوراق النعناع.", price: 14, currency: "SAR", image_url: null, confidence: 1, flags: [] }
      ]
    },
    categories: [
      {
        id: "main_category_24150", name: "معجنات", description: null, image_url: null,
        items: [
          { id: "item_011", name: "منقوشة جبنة وزعتر", name_en: null, description: "جبنة عكاوي مع خلطة الزعتر اللبناني.\n540 سعرات حراريه\nالحساسية: منتجات الألبان، القمح", price: 15, currency: "SAR", image_url: img.jabali, confidence: 1, flags: [] },
          { id: "item_012", name: "فطيرة سبانخ", name_en: null, description: "حشوة السبانخ مع البصل ودبس الرمان والصنوبر.", price: 12, currency: "SAR", image_url: null, confidence: 1, flags: [] },
          { id: "item_013", name: "لحم بعجين", name_en: null, description: "لحم مفروم متبّل مع البندورة والبهارات البلدية.", price: 18, currency: "SAR", image_url: img.zaatar, confidence: 1, flags: [] },
          { id: "item_014", name: "كعكة سمسم", name_en: null, description: "كعكة طرية مغطاة بالسمسم تقدم مع جبنة أو زعتر.\nالحساسية: بذور السمسم ومنتجاتها، القمح", price: 8, currency: "SAR", image_url: null, confidence: 1, flags: [] }
        ]
      },
      {
        id: "main_category_24161", name: "مشروبات ساخنة", description: null, image_url: null,
        items: [
          { id: "item_015", name: "قهوة تركية", name_en: null, description: null, price: 12, currency: "SAR", image_url: null, confidence: 1, flags: [] },
          { id: "item_016", name: "شاي بالنعناع", name_en: null, description: null, price: 10, currency: "SAR", image_url: null, confidence: 1, flags: [] },
          { id: "item_017", name: "لاتيه", name_en: null, description: null, price: 18, currency: "SAR", image_url: img.spanish, confidence: 1, flags: [] },
          { id: "item_018", name: "سحلب بالقرفة", name_en: null, description: "مشروب الحليب الدافئ مع القرفة والمكسرات.", price: 16, currency: "SAR", image_url: null, confidence: 1, flags: [] }
        ]
      },
      {
        id: "main_category_24170", name: "حلويات شرقية", description: null, image_url: null,
        items: [
          { id: "item_019", name: "كنافة بالجبن", name_en: null, description: "كنافة ناعمة بجبنة عكاوي والقطر.\n720 سعرات حراريه\nالحساسية: منتجات الألبان، القمح، المكسرات", price: 24, currency: "SAR", image_url: img.mocha, confidence: 1, flags: [] },
          { id: "item_020", name: "مفروكة بالفستق", name_en: null, description: null, price: 22, currency: "SAR", image_url: null, confidence: 1, flags: [] },
          { id: "item_021", name: "معمول بالتمر", name_en: null, description: null, price: 14, currency: "SAR", image_url: null, confidence: 1, flags: [] }
        ]
      }
    ],
    page_meta: { page_number: 2, footer_url: "menu-p.com", qr_placeholder: true }
  };
})();
