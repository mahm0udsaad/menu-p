// v2 shared system — requires menu-shared.jsx loaded first.

const FONT_BODY2 = "'IBM Plex Sans Arabic', 'Cairo', sans-serif";
const AR_DIGS = '٠١٢٣٤٥٦٧٨٩';
function arDigits(n) { return String(n).replace(/\d/g, function (d) { return AR_DIGS[d]; }); }

const STAR8_CLIP = 'polygon(50% 0%, 64.64% 14.64%, 85.36% 14.64%, 85.36% 35.36%, 100% 50%, 85.36% 64.64%, 85.36% 85.36%, 64.64% 85.36%, 50% 100%, 35.36% 85.36%, 14.64% 85.36%, 14.64% 64.64%, 0% 50%, 14.64% 35.36%, 14.64% 14.64%, 35.36% 14.64%)';

const IMGS2 = {
  zaatar: MENU_DATA.categories[0].items[0].image_url,
  jabali: MENU_DATA.categories[0].items[1].image_url,
  spanish: MENU_DATA.categories[1].items[0].image_url,
  mocha: MENU_DATA.categories[1].items[1].image_url,
  caramel: MENU_DATA.categories[1].items[2].image_url
};

function ItemMeta2(props) {
  if (!props.calories && !props.allergens) return null;
  return (
    <div style={{ display: 'flex', gap: 12, alignItems: 'baseline', flexWrap: 'wrap', marginTop: 3, justifyContent: props.center ? 'center' : 'flex-start' }}>
      {props.calories ? <span style={{ fontSize: 10, fontWeight: 700, color: props.accent }}>{arDigits(props.calories)} سعرة حرارية</span> : null}
      {props.allergens ? <span style={{ fontSize: 10, color: props.muted || '#8A8178' }}>يحتوي: {props.allergens}</span> : null}
    </div>
  );
}

// Generic list row: name — (leader) — price, then description + meta.
function MenuRow(props) {
  const it = props.it;
  const d = parseItemDescription(it.description);
  const ink = props.ink || MENU_INK;
  const muted = props.muted || MENU_MUTED;
  return (
    <div style={{ padding: (props.padY || 9) + 'px 0', borderBottom: props.border === false ? 'none' : '1px ' + (props.borderStyle || 'solid') + ' ' + (props.borderColor || '#EAE1D2') }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'baseline' }}>
        <span style={{ fontSize: props.nameSize || 15, fontWeight: 700, color: ink, fontFamily: props.nameFont || 'inherit' }}>{it.name}</span>
        {props.leader ? (
          <span style={{ flex: 1, borderBottom: '1.5px dotted ' + (props.leaderColor || '#BFB29A'), transform: 'translateY(-3px)', minWidth: 18 }}></span>
        ) : (
          <span style={{ flex: 1 }}></span>
        )}
        <ItemPrice price={it.price} size={props.priceSize || 13.5} accent={props.priceColor || props.accent}></ItemPrice>
      </div>
      {d.body ? <div style={Object.assign({ fontSize: props.descSize || 11.5, lineHeight: 1.7, color: muted, marginTop: 1 }, lineClamp(props.clamp || 2))}>{d.body}</div> : null}
      <ItemMeta2 calories={d.calories} allergens={d.allergens} accent={props.accent} muted={props.metaMuted}></ItemMeta2>
    </div>
  );
}

// «تتمة» chip for categories continuing across pages.
function ContTag(props) {
  const col = props.color || '#8A8178';
  return (
    <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.04em', color: col, border: '1px solid ' + col, padding: '1px 9px 2px', borderRadius: 999, whiteSpace: 'nowrap', alignSelf: 'center' }}>تتمة من الصفحة السابقة</span>
  );
}

function page2FooterText() {
  const m = MENU_DATA.page_meta;
  return 'صفحة ٢ · القائمة الكاملة: ' + arDigits(m.total_known_categories) + ' قسماً، ' + arDigits(m.total_known_items) + ' صنفاً';
}

// Footer pinned to page bottom (parent must be display:flex column).
function MenuFooter(props) {
  const meta = props.meta || MENU_DATA.page_meta;
  return (
    <footer style={{ borderTop: '1px solid ' + (props.border || '#D9CDB9'), paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {meta.qr_placeholder ? <QRPlaceholder size={32} ink={props.ink || MENU_INK}></QRPlaceholder> : null}
        <div style={{ fontSize: 9, color: props.muted || '#8A8178', direction: 'ltr', letterSpacing: '0.08em' }}>{meta.footer_url}</div>
      </div>
      <div style={{ fontSize: 10, color: props.pageMuted || MENU_MUTED }}>{props.text || ('صفحة ' + arDigits(meta.page_number) + ' · يتبع')}</div>
    </footer>
  );
}

// Small inner-page masthead band for page 2.
function MiniBand(props) {
  const R = MENU_DATA.restaurant;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: props.rule || ('2px solid ' + MENU_INK), paddingBottom: 10 }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'baseline' }}>
        <span style={{ fontSize: 21, fontWeight: props.weight || 800, fontFamily: props.font || 'inherit', color: props.ink || MENU_INK }}>{R.name}</span>
        <span style={{ fontSize: 9, letterSpacing: '0.28em', fontWeight: 700, color: props.accent, direction: 'ltr' }}>{R.name_en}</span>
      </div>
      <span style={{ fontSize: 10, color: props.muted || '#8A8178' }}>تتمة القائمة</span>
    </div>
  );
}

Object.assign(window, {
  FONT_BODY2, arDigits, STAR8_CLIP, IMGS2,
  ItemMeta2, MenuRow, ContTag, MenuFooter, MiniBand, page2FooterText
});
